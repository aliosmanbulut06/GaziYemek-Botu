import sqlite3

def get_order_status(order_id: int):
    conn = sqlite3.connect("food_delivery.db")
    cursor = conn.cursor()
    cursor.execute("SELECT status FROM orders WHERE order_id = ?", (order_id,))
    result = cursor.fetchone()
    conn.close()
    if result:
        return result[0]
    return None

def get_price(item_name: str):
    conn = sqlite3.connect("food_delivery.db")
    cursor = conn.cursor()
    cursor.execute("SELECT price FROM food_items WHERE name = ?", (item_name,))
    result = cursor.fetchone()
    conn.close()
    if result:
        return result[0]
    if result:
        return result[0]
    return None

def get_all_food_items():
    conn = sqlite3.connect("food_delivery.db")
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM food_items")
    items = [row[0] for row in cursor.fetchall()]
    conn.close()
    return items

def update_order_status(order_id: int, status: str):
    conn = sqlite3.connect("food_delivery.db")
    cursor = conn.cursor()
    cursor.execute("UPDATE orders SET status = ? WHERE order_id = ?", (status, order_id))
    conn.commit()
    conn.close()

def insert_order(total_price: float, order_items: dict):
    conn = sqlite3.connect("food_delivery.db")
    cursor = conn.cursor()
    
    # Insert into orders
    cursor.execute("INSERT INTO orders (total_price, status) VALUES (?, ?)", (total_price, "Hazırlanıyor"))
    order_id = cursor.lastrowid
    
    # Insert into order_items
    # order_items is a dict {food_name: quantity}
    # We need item_id for each food_name
    for food_name, quantity in order_items.items():
        cursor.execute("SELECT item_id, price FROM food_items WHERE name = ?", (food_name,))
        item_result = cursor.fetchone()
        if item_result:
            item_id = item_result[0]
            price = item_result[1]
            cursor.execute("INSERT INTO order_items (order_id, item_id, quantity, price) VALUES (?, ?, ?, ?)", 
                           (order_id, item_id, quantity, price))
    
    conn.commit()
    conn.close()
    return order_id

def get_total_order_price(order_id: int):
    conn = sqlite3.connect("food_delivery.db")
    cursor = conn.cursor()
    cursor.execute("SELECT total_price FROM orders WHERE order_id = ?", (order_id,))
    result = cursor.fetchone()
    conn.close()
    if result:
        return result[0]
    return 0

def get_all_orders():
    conn = sqlite3.connect("food_delivery.db")
    cursor = conn.cursor()
    # Fetch orders
    cursor.execute("SELECT * FROM orders")
    orders_data = cursor.fetchall()
    
    orders = []
    for row in orders_data:
        order_id = row[0]
        total_price = row[1]
        status = row[2]
        
        # Fetch items for this order
        cursor.execute("""
            SELECT f.name, oi.quantity 
            FROM order_items oi
            JOIN food_items f ON oi.item_id = f.item_id
            WHERE oi.order_id = ?
        """, (order_id,))
        
        items = []
        for item_row in cursor.fetchall():
            items.append(f"{item_row[1]}x {item_row[0]}")
            
        orders.append({
            "order_id": order_id,
            "total_price": total_price,
            "status": status,
            "items": ", ".join(items)
        })
        
    conn.close()
    return orders
