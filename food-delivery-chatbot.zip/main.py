from fastapi import FastAPI, Request, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import datetime
import db_helper
import generic_helper
from nlp_engine import NLPEngine, Context
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize NLP Engine
food_items = db_helper.get_all_food_items()
nlp = NLPEngine(food_items)


# In-memory session storage
# structure: session_id -> {'current_order': {}, 'context': ContextObject}
sessions = {}

class ChatRequest(BaseModel):
    text: str
    session_id: str

class OrderStatusUpdate(BaseModel):
    status: str

def get_session(session_id: str):
    if session_id not in sessions:
        sessions[session_id] = {
            'current_order': {}, 
            'context': None
        }
    return sessions[session_id]

@app.post("/api/chat")
async def chat_endpoint(request: ChatRequest):
    session_id = request.session_id
    text = request.text
    session = get_session(session_id)
    
    # Extract intent
    intent = nlp.extract_intent(text, session.get('context'))
    fulfillment_text = "Anlayamadım, tekrar eder misiniz?"
    
    # --- Intent Handling ---
    
    if intent == "greeting":
        fulfillment_text = "Merhaba! Yemek siparişi vermek ister misiniz? Menümüzde lahmacun, pide, döner ve daha fazlası var."
    
    elif intent == "order.add":
        items = nlp.extract_food_items(text)
        if items:
            current_order = session['current_order']
            added_items_str = []
            for food, qty in items.items():
                if food in current_order:
                    current_order[food] += qty
                else:
                    current_order[food] = qty
                added_items_str.append(f"{qty} adet {food}")
            
            fulfillment_text = f"Sepete eklendi: {', '.join(added_items_str)}. Başka bir arzunuz var mı?"
        else:
            fulfillment_text = "Ne eklemek istediğinizi anlayamadım. Örneğin '2 lahmacun ekle' diyebilirsiniz."

    elif intent == "order.remove":
        # Simplified removal logic
        fulfillment_text = "Ürün çıkarma henüz tam aktif değil, ama sepetinizi sıfırlayabilirim. 'İptal' diyerek baştan başlayabilirsiniz."
        
    elif intent == "order.complete":
        current_order = session['current_order']
        if current_order:
            order_id = save_to_db(current_order)
            total_price = db_helper.get_total_order_price(order_id)
            fulfillment_text = f"Siparişiniz alındı! Sipariş No: {order_id}. Toplam Tutar: {total_price} TL. Hazırlanıyor..."
            # Reset session
            sessions[session_id] = {'current_order': {}, 'context': None}
        else:
            fulfillment_text = "Sepetiniz boş. Lütfen önce bir şeyler ekleyin."

    elif intent == "track.order":
        order_id = nlp.extract_order_id(text)
        if order_id:
            status = db_helper.get_order_status(order_id)
            if status:
                fulfillment_text = f"{order_id} numaralı siparişinizin durumu: {status}"
            else:
                fulfillment_text = "Böyle bir sipariş bulunamadı."
        else:
            fulfillment_text = "Hangi siparişi sormuştunuz? Lütfen sipariş numarasını belirtin."
            
    # Default fallback for simple chit-chat or unknown
    elif not intent:
        # If we have items in cart, maybe remind them?
        if session['current_order']:
             fulfillment_text = "Sepetinizde ürünler var. Tamamlamak için 'siparişi ver' diyebilirsiniz."
        
    return JSONResponse(content={
        "fulfillmentText": fulfillment_text
    })

@app.get("/orders")
async def get_orders():
    return db_helper.get_all_orders()

@app.post("/api/orders/{order_id}/status")
async def update_status(order_id: int, status_update: OrderStatusUpdate):
    db_helper.update_order_status(order_id, status_update.status)
    return {"message": "Status updated"}

def save_to_db(order: dict):
    total_price = 0
    for item, quantity in order.items():
        price = db_helper.get_price(item)
        if price is None: price = 0
        total_price += price * quantity
    
    return db_helper.insert_order(total_price, order)

# Serve frontend static files
# Ensure the directory exists before mounting to avoid errors if path is wrong
frontend_path = os.path.join(os.path.dirname(__file__), "frontend")
if os.path.exists(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")
