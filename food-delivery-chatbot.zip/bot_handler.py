import json
import datetime

# --- Handler Functions ---
def handle_hello():
    return "Merhaba! Size nasıl yardımcı olabilirim?"

def handle_time():
    now = datetime.datetime.now()
    return f"Şu an saat: {now.strftime('%H:%M:%S')}"

def handle_help():
    return "Kullanabileceğiniz komutlar: merhaba, saat, yardım. Ayrıca yemek siparişi de verebilirsiniz!"

# Map string names to actual functions
HANDLER_MAP = {
    "handle_hello": handle_hello,
    "handle_time": handle_time,
    "handle_help": handle_help
}

# --- Core Functions ---

def load_commands(file_path="commands.json"):
    """
    commands.json dosyasını okuyup komutları listesi olarak döndürür.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            commands = json.load(f)
        return commands
    except FileNotFoundError:
        print(f"Hata: {file_path} bulunamadı.")
        return []
    except json.JSONDecodeError:
        print(f"Hata: {file_path} geçerli bir JSON dosyası değil.")
        return []

def process_message(message_text, commands):
    """
    Gelen mesajı kontrol eder ve eşleşen bir komut varsa handler'ını çağırır.
    """
    message_text = message_text.lower()
    
    for command in commands:
        triggers = command.get("triggers", [])
        handler_name = command.get("handler_function")
        
        # Mesajdaki kelimelerden herhangi biri trigger listesinde var mı kontrol et
        # Basitçe mesajın içinde geçiyor mu diye bakıyoruz (contains)
        for trigger in triggers:
            if trigger in message_text:
                if handler_name in HANDLER_MAP:
                    return HANDLER_MAP[handler_name]()
                else:
                    return f"Hata: {handler_name} fonksiyonu tanımlı değil."
    
    return None # Eşleşme yoksa None dön

# --- Test ---
if __name__ == "__main__":
    print("Komutlar yükleniyor...")
    loaded_commands = load_commands()
    
    if loaded_commands:
        print(f"{len(loaded_commands)} komut yüklendi.")
        
        test_messages = ["Selam bot", "saat kaç?", "bana yardım et", "nasılsın"]
        
        for msg in test_messages:
            print(f"\nMesaj: '{msg}'")
            response = process_message(msg, loaded_commands)
            if response:
                print(f"Cevap: {response}")
            else:
                print("Cevap: (Komut eşleşmedi)")
