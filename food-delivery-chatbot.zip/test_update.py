from nlp_engine import NLPEngine
import db_helper
import sqlite3

def test_updates():
    print("--- Database Verification ---")
    conn = sqlite3.connect("food_delivery.db")
    cursor = conn.cursor()
    cursor.execute("SELECT name, price FROM food_items WHERE name IN ('SSK', 'Mercimek Çorbası', 'Samosa', 'İskender')")
    items = cursor.fetchall()
    conn.close()
    
    found_names = [item[0] for item in items]
    print(f"Items found: {found_names}")
    
    if 'SSK' in found_names and 'Mercimek Çorbası' in found_names:
        print("PASS: New items found.")
    else:
        print("FAIL: New items missing.")
        
    if 'Samosa' not in found_names:
        print("PASS: Samosa successfully removed.")
    else:
        print("FAIL: Samosa still exists.")

    print("\n--- NLP Verification ---")
    # Reload food items from DB for NLP
    all_items = db_helper.get_all_food_items()
    nlp = NLPEngine(all_items)
    
    # Test Time
    intent_time = nlp.extract_intent("Saat kaç")
    print(f"'Saat kaç' intent: {intent_time}")
    if intent_time == 'time.get':
        print("PASS: Time intent detected.")
    else:
        print("FAIL: Time intent NOT detected.")
        
    # Test Order with new keyword
    intent_order = nlp.extract_intent("SSK gönder")
    print(f"'SSK gönder' intent: {intent_order}")
    if intent_order == 'order.add':
        print("PASS: Order intent with 'gönder' detected.")
    else:
        print("FAIL: Order intent with 'gönder' NOT detected.")
        
    # Test Extraction
    items_extracted = nlp.extract_food_items("2 porsiyon ssk ve bir mercimek istiyorum")
    print(f"Extracted items: {items_extracted}")
    if 'ssk' in items_extracted and 'mercimek çorbası' in items_extracted: # assuming lowercase mapping
         print("PASS: New items extracted correctly.")
    else:
         print("FAIL: Extraction issues.")

if __name__ == "__main__":
    test_updates()
