import sqlite3
import os

def create_database():
    # Helper to clean up old DB if needed, but for now we just overwrite or append?
    # Actually, to refresh the menu, it's cleaner to drop and recreate or just handle duplicates.
    # Since this is a dev environment, let's just connect.
    
    conn = sqlite3.connect('food_delivery.db')
    cursor = conn.cursor()

    # Create food_items table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS food_items (
            item_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL
        )
    ''')

    # Create orders table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            order_id INTEGER PRIMARY KEY AUTOINCREMENT,
            total_price REAL NOT NULL,
            status TEXT NOT NULL
        )
    ''')

    # Create order_items table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS order_items (
            order_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER,
            item_id INTEGER,
            quantity INTEGER,
            price REAL,
            FOREIGN KEY (order_id) REFERENCES orders (order_id),
            FOREIGN KEY (item_id) REFERENCES food_items (item_id)
        )
    ''')
    
    # Check if we should clear existing items to avoid duplicates or old items
    cursor.execute("DELETE FROM food_items")

    # Seed food_items with Turkish Cuisine
    food_items = [
        # Aspava Mains
        ('İskender', 350),
        ('SSK', 400),
        ('Beyti', 380),
        ('Dürüm', 200),
        ('Pilav Üstü Döner', 320),
        ('Adana Kebap', 300),
        ('Lahmacun', 80),
        
        # Soups
        ('Mercimek Çorbası', 90),
        ('Mercimek', 90), # Alias
        ('Yayla Çorbası', 90),
        ('Yayla', 90), # Alias
        
        # Desserts
        ('Triliçe', 90),
        ('İrmik Helvası', 0), # Treat but also listed
        
        # Drinks
        ('Kola', 40),
        ('Ayran', 20),
        ('Su', 10),
        ('Soda', 15),
        ('Şalgam', 25),
        ('Gazoz', 25),
        ('Meyve Suyu', 30),
        
        # Treats (0 TL)
        ('Salata', 0),
        ('Cacık', 0),
        ('Çiğ Köfte', 0),
        ('Patates Kızartması', 0),
        ('Mantar Soslu Patates', 0),
        ('Semaver Çay', 0)
    ]

    cursor.executemany('INSERT INTO food_items (name, price) VALUES (?, ?)', food_items)
    
    # Seed a few dummy orders for tracking
    # Check if orders exist first? Or just clear them too for a fresh start.
    # Let's keep orders if possible, but for dev usually fresh is fine.
    # cursor.execute("DELETE FROM orders") 
    # cursor.execute("DELETE FROM order_items")
    
    # Add dummy orders only if table is empty
    cursor.execute("SELECT count(*) FROM orders")
    if cursor.fetchone()[0] == 0:
        orders = [
            (40, 'Yolda'),
            (41, 'Teslim Edildi')
        ]
        cursor.executemany('INSERT INTO orders (order_id, total_price, status) VALUES (?, 0, ?)', orders)

    conn.commit()
    conn.close()
    print("Database updated with Turkish Menu successfully.")

if __name__ == "__main__":
    create_database()
