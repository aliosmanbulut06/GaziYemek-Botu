from fastapi.testclient import TestClient
from main import app
from main import app


client = TestClient(app)

def test_chat_greeting():
    response = client.post("/api/chat", json={"text": "selam", "session_id": "test_session_1"})
    assert response.status_code == 200
    data = response.json()
    assert "fulfillmentText" in data
    assert "Merhaba" in data["fulfillmentText"]

def test_chat_order_add():
    response = client.post("/api/chat", json={"text": "2 lahmacun ekle", "session_id": "test_session_1"})
    assert response.status_code == 200
    data = response.json()
    assert "Sepete eklendi" in data["fulfillmentText"]
    assert "2 adet Lahmacun" in data["fulfillmentText"]


def test_chat_order_complete():
    # First add something
    client.post("/api/chat", json={"text": "1 kola ekle", "session_id": "test_session_2"})
    
    response = client.post("/api/chat", json={"text": "siparişi ver", "session_id": "test_session_2"})
    assert response.status_code == 200
    data = response.json()
    print("Complete Order Response:", data["fulfillmentText"])
    # Avoid encoding issues by checking substring or ASCII parts
    assert "Siparis" in data["fulfillmentText"] or "Sipariş" in data["fulfillmentText"] or "alim" in data["fulfillmentText"] or "aldı" in data["fulfillmentText"] or "alındı" in data["fulfillmentText"] or "No:" in data["fulfillmentText"]


def test_get_orders():
    response = client.get("/orders")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

if __name__ == "__main__":
    # If not using pytest directly, simple run
    try:
        test_chat_greeting()
        print("test_chat_greeting passed")
        test_chat_order_add()
        print("test_chat_order_add passed")
        test_chat_order_complete()
        print("test_chat_order_complete passed")
        test_get_orders()
        print("test_get_orders passed")
        print("All tests passed!")
    except Exception:
        import traceback
        traceback.print_exc()
