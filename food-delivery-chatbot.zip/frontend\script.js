const chatWindow = document.getElementById('chat-window');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const ordersTableBody = document.getElementById('orders-table-body');
const refreshBtn = document.getElementById('refresh-btn');

// Generate a random session ID or use a fixed one for demo
const sessionId = 'session-' + Math.random().toString(36).substr(2, 9);
const API_BASE = 'http://127.0.0.1:8000';

// Chat Logic
sendBtn.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

async function sendMessage() {
    const text = userInput.value.trim();
    if (!text) return;

    addMessage(text, 'user-message');
    userInput.value = '';

    // Show typing indicator? (Optional enhancement)

    try {
        const response = await fetch(`${API_BASE}/api/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: text, session_id: sessionId })
        });

        if (!response.ok) throw new Error('Network response was not ok');

        const data = await response.json();
        addMessage(data.fulfillmentText, 'bot-message');

        // Auto-refresh orders if order was potentially created/updated
        // We can optimize this but for now refresh on every message is safe enough for a demo
        setTimeout(fetchOrders, 1000);

    } catch (error) {
        console.error(error);
        addMessage('Sunucuyla iletişimde bir hata oluştu.', 'bot-message');
    }
}

function addMessage(text, className) {
    const div = document.createElement('div');
    div.className = `message ${className}`;
    div.textContent = text;
    chatWindow.appendChild(div);
    chatWindow.scrollTop = chatWindow.scrollHeight;
}

// Kitchen View Logic
async function fetchOrders() {
    try {
        const response = await fetch(`${API_BASE}/orders`);
        const orders = await response.json();
        renderOrders(orders);
    } catch (error) {
        console.error('Error fetching orders:', error);
    }
}

function renderOrders(orders) {
    ordersTableBody.innerHTML = '';
    // Reverse orders to show newest first
    orders.reverse().forEach(order => {
        const tr = document.createElement('tr');

        let statusClass = 'status-hazirlaniyor';
        if (order.status === 'Yolda') statusClass = 'status-yolda';
        if (order.status === 'Teslim Edildi') statusClass = 'status-teslim';

        tr.innerHTML = `
            <td>#${order.order_id}</td>
            <td class="order-items">${order.items}</td>
            <td>${order.total_price} TL</td>
            <td><span class="status-badge ${statusClass}">${order.status}</span></td>
            <td>
                <button class="action-btn btn-prepare" onclick="updateStatus(${order.order_id}, 'Hazırlanıyor')">Hazırla</button>
                <button class="action-btn btn-deliver" onclick="updateStatus(${order.order_id}, 'Yolda')">Yola Çıkar</button>
                <button class="action-btn btn-complete" onclick="updateStatus(${order.order_id}, 'Teslim Edildi')">Teslim Et</button>
            </td>
        `;
        ordersTableBody.appendChild(tr);
    });
}

async function updateStatus(orderId, newStatus) {
    try {
        const response = await fetch(`${API_BASE}/api/orders/${orderId}/status`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus })
        });

        if (response.ok) {
            fetchOrders(); // Refresh table
        } else {
            console.error('Failed to update status');
        }
    } catch (error) {
        console.error('Error updating status:', error);
    }
}

// Expose updateStatus to window for onclick handlers
window.updateStatus = updateStatus;

refreshBtn.addEventListener('click', fetchOrders);

// Initial fetch
fetchOrders();
