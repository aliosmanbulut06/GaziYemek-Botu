import re
import difflib

class Context:
    def __init__(self, name: str, lifespan: int = 2, parameters: dict = None):
        self.name = name
        self.lifespan = lifespan
        self.parameters = parameters or {}

    def decrement(self):
        self.lifespan -= 1
        return self.lifespan > 0

class NLPEngine:
    def __init__(self, food_items):
        self.food_items = [item.lower() for item in food_items]
        self.food_mapping = {item.lower(): item for item in food_items} # map lower to original

    def extract_intent(self, text, current_context=None):
        text = text.lower()
        
        # Context-aware intents
        if current_context:
            if current_context.name == 'awaiting_confirmation':
                if any(x in text for x in ["evet", "onayla", "tamam", "olsun"]):
                    return "confirmation.yes"
                if any(x in text for x in ["hayır", "iptal", "vazgeç", "yok"]):
                    return "confirmation.no"
        
        # Order Add Patterns
        if any(x in text for x in ["istiyorum", "yolla", "ekle", "alabilir miyim", "verir misin", "var mı", "gönder", "gelsin", "çek"]):
            return "order.add"
        
        # Order Remove Patterns
        if any(x in text for x in ["çıkar", "sil", "istemiyorum", "iptal"]):
            return "order.remove"
        
        # Order Complete Patterns
        if any(x in text for x in ["tamamla", "bitir", "sipariş ver", "siparişi", "onayla", "hesap"]):
            return "order.complete"
        
        # Track Order Patterns
        if any(x in text for x in ["durum", "nerede", "takip", "ne oldu"]):
            return "track.order"
            
        # Time Patterns
        if any(x in text for x in ["saat", "vakit", "kaçta"]):
            return "time.get"
            
        # Greeting Patterns
        if any(x in text for x in ["selam", "merhaba", "naber", "hey", "günaydın", "iyi akşamlar"]):
            return "greeting"
            
        return None

    def extract_food_items(self, text):
        text = text.lower()
        detected_items = {}
        
        # Clean text
        text = re.sub(r'[^\w\s]', ' ', text)
        words = text.split()
        
        i = 0
        while i < len(words):
            word = words[i]
            
            # Check for direct match or close match
            match = difflib.get_close_matches(word, self.food_items, n=1, cutoff=0.7)
            
            # Also check two-word items (e.g. "Mercimek Çorbası")
            if i + 1 < len(words):
                double_word = f"{word} {words[i+1]}"
                double_match = difflib.get_close_matches(double_word, self.food_items, n=1, cutoff=0.7)
                if double_match:
                    match = double_match
                    i += 1 # Skip next word
            
            if match:
                food_name = self.food_mapping[match[0]]
                quantity = 1
                
                # Check previous word for number
                if i > 0:
                    prev_word = words[i-1]
                    # Try to parse number
                    try:
                        quantity = int(prev_word)
                    except ValueError:
                        if prev_word == "bir": quantity = 1
                        elif prev_word == "iki": quantity = 2
                        elif prev_word == "üç": quantity = 3
                        elif prev_word == "buçuk": pass # handle 1.5 logic if needed?
                
                # Add to detected items
                if food_name in detected_items:
                    detected_items[food_name] += quantity
                else:
                    detected_items[food_name] = quantity
            
            i += 1
            
        return detected_items

    def extract_order_id(self, text):
        match = re.search(r'\b\d+\b', text)
        if match:
            return int(match.group())
        return None
