import logging

# Check if google-cloud-dialogflow is installed
try:
    from google.cloud import dialogflow
    DIALOGFLOW_AVAILABLE = True
except ImportError:
    DIALOGFLOW_AVAILABLE = False

class DialogflowClient:
    def __init__(self, project_id, language_code='tr'):
        self.project_id = project_id
        self.language_code = language_code
        self.session_client = None
        
        if DIALOGFLOW_AVAILABLE:
            # Explicitly checking for credentials or handling them is usually done via env vars
            # export GOOGLE_APPLICATION_CREDENTIALS="path/to/key.json"
            try:
                self.session_client = dialogflow.SessionsClient()
            except Exception as e:
                logging.error(f"Failed to initialize Dialogflow client: {e}")
        else:
            logging.warning("Dialogflow library not installed. Using fallback mode.")

    def detect_intent(self, session_id, text):
        if not self.session_client:
            return None
        
        session = self.session_client.session_path(self.project_id, session_id)
        text_input = dialogflow.TextInput(text=text, language_code=self.language_code)
        query_input = dialogflow.QueryInput(text=text_input)

        try:
            response = self.session_client.detect_intent(
                request={"session": session, "query_input": query_input}
            )
            return response.query_result
        except Exception as e:
            logging.error(f"Dialogflow API call failed: {e}")
            return None
