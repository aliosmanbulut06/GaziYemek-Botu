import requests
import json

def test_track_order():
    url = "http://127.0.0.1:8000/"
    payload = {
        "queryResult": {
            "intent": {
                "displayName": "track.order - context: ongoing-tracking"
            },
            "parameters": {
                "order_id": "40"
            },
            "outputContexts": [
                {"name": "projects/newagent-123/agent/sessions/12345/contexts/ongoing-tracking"}
            ]
        }
    }
    response = requests.post(url, json=payload)
    print("Track Order Response:", response.json())

def test_add_to_order():
    url = "http://127.0.0.1:8000/"
    payload = {
        "queryResult": {
            "intent": {
                "displayName": "order.add - context: ongoing-order"
            },
            "parameters": {
                "food-item": ["Samosa", "Pav Bhaji"],
                "number": [2, 1]
            },
            "outputContexts": [
                {"name": "projects/newagent-123/agent/sessions/12345/contexts/ongoing-order"}
            ]
        }
    }
    response = requests.post(url, json=payload)
    print("Add to Order Response:", response.json())

def test_complete_order():
    url = "http://127.0.0.1:8000/"
    payload = {
        "queryResult": {
            "intent": {
                "displayName": "order.complete - context: ongoing-order"
            },
            "parameters": {},
            "outputContexts": [
                {"name": "projects/newagent-123/agent/sessions/12345/contexts/ongoing-order"}
            ]
        }
    }
    response = requests.post(url, json=payload)
    print("Complete Order Response:", response.json())

if __name__ == "__main__":
    test_track_order()
    test_add_to_order()
    test_complete_order()
