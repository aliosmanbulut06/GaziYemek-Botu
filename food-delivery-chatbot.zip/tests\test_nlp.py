import unittest
from nlp_engine import NLPEngine

class TestNLPEngine(unittest.TestCase):
    def setUp(self):
        food_items = ['Pizza', 'Samosa', 'Iskender', 'Lahmacun']
        self.nlp = NLPEngine(food_items)

    def test_intent_add(self):
        text = "2 pizza istiyorum"
        self.assertEqual(self.nlp.extract_intent(text), "order.add")
        
    def test_intent_greeting(self):
        text = "Selam naber"
        self.assertEqual(self.nlp.extract_intent(text), "greeting")
        
    def test_intent_track(self):
        text = "sipariş durumu ne"
        self.assertEqual(self.nlp.extract_intent(text), "track.order")

    def test_entity_extraction_simple(self):
        text = "2 samosa"
        items = self.nlp.extract_food_items(text)
        self.assertEqual(items.get('Samosa'), 2)
        
    def test_entity_extraction_fuzzy(self):
        text = "bana bir isknder yolla" # typo intended
        items = self.nlp.extract_food_items(text)
        self.assertEqual(items.get('Iskender'), 1)
    
    def test_entity_extraction_complex(self):
        text = "2 lahmacun ve 1 pizza ver"
        items = self.nlp.extract_food_items(text)
        self.assertEqual(items.get('Lahmacun'), 2)
        self.assertEqual(items.get('Pizza'), 1)

if __name__ == '__main__':
    unittest.main()
