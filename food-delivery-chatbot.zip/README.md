# Yemek Sipariş Chatbotu (Food Delivery Chatbot)

Bu proje, FastAPI ve SQLite kullanılarak geliştirilmiş bir yemek sipariş chatbotu arka ucudur (backend). Ayrıca, chatbotu test etmek ve siparişleri yönetmek için basit bir web arayüzü (Dashboard) içerir.

## Özellikler

*   **Sipariş Verme:** Kullanıcılar yemek siparişi verebilir (Örn: "2 samosa istiyorum").
*   **Sipariş Takibi:** Kullanıcılar sipariş durumunu sorgulayabilir (Örn: "40 numaralı siparişin durumu ne?").
*   **Dinamik Komutlar:** `commands.json` üzerinden yapılandırılabilen özel komutlar (Örn: "selam", "saat", "yardım").
*   **Yönetim Paneli (Dashboard):**
    *   **Sohbet Simülatörü:** Botu tarayıcı üzerinden test etme imkanı.
    *   **Mutfak Görünümü:** Gelen siparişleri canlı olarak listeleme.
*   **Veritabanı:** SQLite veritabanı ile siparişlerin ve menünün saklanması.

## Kurulum

1.  **Gereksinimleri Yükleyin:**
    Proje dizininde terminali açın ve gerekli Python kütüphanelerini yükleyin:
    ```bash
    pip install -r requirements.txt
    ```

2.  **Veritabanını Oluşturun:**
    Veritabanını başlatmak ve örnek verileri eklemek için şu komutu çalıştırın:
    ```bash
    python create_db.py
    ```

## Çalıştırma

Sunucuyu başlatmak için iki yöntem vardır:

**Yöntem 1: `run.bat` dosyasını kullanma (Önerilen)**
Proje klasöründeki `run.bat` dosyasına çift tıklayın. Bu işlem sunucuyu otomatik olarak başlatacaktır.

**Yöntem 2: Terminal üzerinden başlatma**
Terminalde şu komutu çalıştırın:
```bash
python -m uvicorn main:app --reload
```

Sunucu `http://127.0.0.1:8000` adresinde çalışmaya başlayacaktır.

## Kullanım

### Dashboard (Yönetim Paneli)
1.  Sunucu çalışırken, tarayıcınızda `frontend/index.html` dosyasını açın.
2.  **Sol Panel (Sohbet Simülatörü):** Buradan bot ile konuşabilirsiniz.
    *   "2 samosa istiyorum"
    *   "sipariş ver"
    *   "selam"
    *   "saat kaç"
3.  **Sağ Panel (Mutfak Görünümü):** "Siparişleri Yenile" butonuna basarak veritabanındaki tüm siparişleri görebilirsiniz.

### Komut Sistemi
Botun cevap vereceği basit komutlar `commands.json` dosyasında tanımlıdır. Yeni komut eklemek için bu dosyayı düzenleyebilirsiniz:
```json
{
  "name": "yeni_komut",
  "triggers": ["tetikleyici1", "tetikleyici2"],
  "handler_function": "fonksiyon_adi"
}
```
Ardından `bot_handler.py` dosyasına ilgili fonksiyonu eklemeniz gerekir.

## Proje Yapısı

*   `main.py`: FastAPI uygulamasının ana dosyası. Webhook ve API endpoint'lerini içerir.
*   `db_helper.py`: Veritabanı işlemlerini (okuma/yazma) yapan yardımcı fonksiyonlar.
*   `generic_helper.py`: Metin işleme gibi genel yardımcı fonksiyonlar.
*   `bot_handler.py`: Dinamik komutları yükleyen ve işleyen modül.
*   `commands.json`: Dinamik komutların tanımlandığı yapılandırma dosyası.
*   `create_db.py`: Veritabanını oluşturan ve örnek veri ekleyen script.
*   `frontend/`: Web arayüzü dosyaları (`index.html`, `style.css`, `script.js`).
